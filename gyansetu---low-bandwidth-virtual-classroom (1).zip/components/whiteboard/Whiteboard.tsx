import React, { useRef, useEffect, useState } from 'react';
import { DrawingData } from '../../types';

interface WhiteboardProps {
  isEducator: boolean;
  classId: string;
}

const Whiteboard: React.FC<WhiteboardProps> = ({ isEducator, classId }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const contextRef = useRef<CanvasRenderingContext2D | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const drawingDataRef = useRef<DrawingData[]>([]);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  // Ref to track the last seen data to prevent unnecessary redraws
  const lastStoredDataRef = useRef<string | null>(null);

  const STORAGE_KEY = `gyansetu_whiteboard_${classId}`;

  const loadAndDrawFromStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY);
    lastStoredDataRef.current = data;

    const context = contextRef.current;
    const canvas = canvasRef.current;
    if (!context || !canvas) return;

    // Always clear before redrawing
    context.clearRect(0, 0, canvas.width, canvas.height);

    if (data) {
      const parsedData: DrawingData[] = JSON.parse(data);
      drawingDataRef.current = parsedData; // Keep local ref in sync for educator
      
      parsedData.forEach(line => {
        context.strokeStyle = line.color;
        context.beginPath();
        context.moveTo(line.x0, line.y0);
        context.lineTo(line.x1, line.y1);
        context.stroke();
      });
      
      // Reset to default color for next drawing
      context.strokeStyle = 'black';
    } else {
        drawingDataRef.current = []; // Data was cleared
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
        const parent = canvas.parentElement;
        if(parent) {
            canvas.width = parent.clientWidth;
            canvas.height = parent.clientHeight;
            // Force a full redraw on resize
            loadAndDrawFromStorage();
        }
    };
    
    const context = canvas.getContext('2d');
    if (context) {
      context.lineCap = 'round';
      context.strokeStyle = 'black';
      context.lineWidth = 3;
      contextRef.current = context;
    }

    resizeCanvas(); // Initial size and draw
    window.addEventListener('resize', resizeCanvas);

    let syncInterval: number | undefined;

    if (!isEducator) {
      // For students, poll localStorage. This is more reliable for real-time updates
      // than the 'storage' event which can be inconsistent.
      syncInterval = window.setInterval(() => {
        const currentData = localStorage.getItem(STORAGE_KEY);
        if (currentData !== lastStoredDataRef.current) {
          loadAndDrawFromStorage();
        }
      }, 100); // Check for updates 10 times per second
    }

    return () => {
        window.removeEventListener('resize', resizeCanvas);
        if (syncInterval) {
            clearInterval(syncInterval);
        }
    };
  }, [classId, isEducator]); // Effect depends on these props

  
  const getCoords = (e: React.MouseEvent | React.TouchEvent): {x: number, y: number} => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    
    if (window.TouchEvent && e.nativeEvent instanceof TouchEvent && e.nativeEvent.touches.length > 0) {
        return {
            x: e.nativeEvent.touches[0].clientX - rect.left,
            y: e.nativeEvent.touches[0].clientY - rect.top
        };
    }
    const mouseEvent = e as React.MouseEvent;
    return {
        x: mouseEvent.clientX - rect.left,
        y: mouseEvent.clientY - rect.top,
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isEducator) return;
    const { x, y } = getCoords(e);
    contextRef.current?.beginPath();
    contextRef.current?.moveTo(x, y);
    setIsDrawing(true);
    lastPointRef.current = { x, y };
  };

  const finishDrawing = () => {
    if (!isEducator || !isDrawing) return;
    contextRef.current?.closePath();
    setIsDrawing(false);
    lastPointRef.current = null;
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !isEducator) return;
    e.preventDefault();
    
    const { x, y } = getCoords(e);
    const context = contextRef.current;
    if (context && lastPointRef.current) {
        const x0 = lastPointRef.current.x;
        const y0 = lastPointRef.current.y;

        context.lineTo(x, y);
        context.stroke();
        
        const newLine: DrawingData = {
          x0: x0,
          y0: y0,
          x1: x,
          y1: y,
          color: context.strokeStyle as string
        };
        
        drawingDataRef.current.push(newLine);
        const dataToStore = JSON.stringify(drawingDataRef.current);
        localStorage.setItem(STORAGE_KEY, dataToStore);
        lastStoredDataRef.current = dataToStore; // Update local ref immediately

        lastPointRef.current = { x, y };
    }
  };
  
  const clearCanvas = () => {
    if(!isEducator) return;
    const canvas = canvasRef.current;
    const context = contextRef.current;
    if (canvas && context) {
      context.clearRect(0, 0, canvas.width, canvas.height);
      drawingDataRef.current = [];
      const dataToStore = JSON.stringify([]);
      localStorage.setItem(STORAGE_KEY, dataToStore);
      lastStoredDataRef.current = dataToStore; // Update local ref immediately
    }
  };
  
  const setColor = (color: string) => {
    if(!isEducator || !contextRef.current) return;
    contextRef.current.strokeStyle = color;
  };

  return (
    <div className="w-full h-full relative">
        <canvas
            ref={canvasRef}
            onMouseDown={startDrawing}
            onMouseUp={finishDrawing}
            onMouseOut={finishDrawing}
            onMouseMove={draw}
            onTouchStart={startDrawing}
            onTouchEnd={finishDrawing}
            onTouchMove={draw}
            className={`w-full h-full ${isEducator ? 'cursor-crosshair' : 'cursor-default'}`}
        />
        {isEducator && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-gray-700 p-2 rounded-lg shadow-lg flex space-x-2">
                <button onClick={() => setColor('black')} className="w-8 h-8 bg-black rounded-full border-2 border-white"></button>
                <button onClick={() => setColor('red')} className="w-8 h-8 bg-red-500 rounded-full"></button>
                <button onClick={() => setColor('blue')} className="w-8 h-8 bg-blue-500 rounded-full"></button>
                <button onClick={() => setColor('green')} className="w-8 h-8 bg-green-500 rounded-full"></button>
                <button onClick={clearCanvas} className="px-3 py-1 bg-gray-200 text-black rounded-md text-sm font-semibold">Clear</button>
            </div>
        )}
        {!isEducator && (
             <div className="absolute top-2 left-2 bg-black bg-opacity-50 px-3 py-1 rounded-full text-sm">
                Viewing Mode
            </div>
        )}
    </div>
  );
};

export default Whiteboard;
